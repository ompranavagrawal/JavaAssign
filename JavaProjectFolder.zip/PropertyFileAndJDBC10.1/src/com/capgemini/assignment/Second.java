package com.capgemini.assignment;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;



public class Second {
	static Connection con=null;
	static Scanner sc=new Scanner(System.in);
	
	
	
	private static void showMenu()
	{
		System.out.println("1. Insert Into table");
		System.out.println("2. View Details of table");
		System.out.println("3. Delete from table");
		System.out.println("4. update value in table");
		System.out.println("5. Exit");
		System.out.println("Enter Your Choice");
	}
	public static void main(String[] args) {
		
		try
		{
		while(true)
		{
			showMenu();
			int ch=sc.nextInt();
			switch(ch)
			{
			case 1: insertDetails();break;
			case 2: showDetails();break;
			case 3: deleteEmployee();break;
			case 4: updateDetails();break;
			case 5:System.exit(0);
			default:System.out.println("Invalid input");
			
			}
			
		}
		}
		catch(ClassNotFoundException| SQLException e)
		{
			e.printStackTrace();
		}
			
		}
	static void createConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection(
				"jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","Lab1btrg21","lab1boracle");
	}
	
	
	private static void insertDetails() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		createConnection();
		System.out.println("Enter Employee id :");
		int empId=sc.nextInt();
		System.out.println("Enter employee name :");
		String empNmae=sc.next();
		System.out.println("Enter employee salary :");
		int empSal=sc.nextInt();
		System.out.println("Enter Employee Designation :");
		String empDesig=sc.next();
		System.out.println("Enter employee insurance Scheme :");
		String empIns=sc.next();
		String query="insert into employee_157754 values(?,?,?,?,?)";
		
		PreparedStatement pst=con.prepareStatement(query);
		pst.setInt(1,empId);
		pst.setString(2,empNmae);
		pst.setInt(3,empSal);
		pst.setString(4, empDesig);
		pst.setString(5,empIns);
		
		int data=pst.executeUpdate();
		if(data!=0)
		System.out.println("Data Inserted successfully");
		con.close();
	}
	private static void showDetails() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		createConnection();
		
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from employee_157754"); 
		
		while(rs.next()) { 
		System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getFloat(3)+" " +rs.getString(4)+" " +rs.getString(5));  
		}
		
		con.close();
	}
	private static void deleteEmployee() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		createConnection();
		System.out.println("Enter Employee id to delete:");
		int empId=sc.nextInt();
		String query="delete from employee_157754 where emp_id=?";
		
		PreparedStatement pmt=con.prepareStatement(query);
		pmt.setInt(1,empId);
		
		int data=pmt.executeUpdate();
		if(data!=0)
			System.out.println("Record Deleted Successfully");
		con.close();
		
	}
	private static void updateDetails() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		createConnection();
		System.out.println("Enter Employee id for which you want to update name and salary:");
		int empId=sc.nextInt();
		System.out.println("Enter updated name :");
		String empNmae=sc.next();
		System.out.println("Enter updated salary :");
		int empSal=sc.nextInt();
		System.out.println("Enter updated Designation :");
		String empDesig=sc.next();
		System.out.println("Enter updated insurance Scheme :");
		String empIns=sc.next();	
		String query="update employee_157754 set emp_name=?,emp_salary=?,emp_designation=?,emp_insurance=? where emp_id=?";
		
		PreparedStatement pmt=con.prepareStatement(query);
		pmt.setString(1, empNmae);
		pmt.setInt(2, empSal);
		pmt.setString(3, empDesig);
		pmt.setString(4,empIns);
		pmt.setInt(5,empId);
		int data=pmt.executeUpdate();
		
		if(data!=0)
			System.out.println("Updated Successfully");
		
		
	}
	
}


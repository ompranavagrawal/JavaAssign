package com.capgemini.bean;

public class Account {
	private static long accNumGenerate=100001;
	 private long accNum=accNumGenerate;
	 private double balance;
	 Person accHolder;
	 
	public void deposit(double amount) {
		 balance=balance+amount;
	 }
	 public void withdraw(double amount) {
		 if(balance>=amount)
			 balance=balance-amount;
		 else
			 System.out.println("Insufficient Balance");
	 }
	 public double getBalance()
	 {
		 return balance;
	 }
	 public void setBalance(double balance)
	 {
		 this.balance=balance;
	 }
	 
	public  long getAccNum() {
		return accNum;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public Account() {
		
		accNum=accNumGenerate++;
	}
	public Account(double balance, Person accHolder) {
		accNum=accNumGenerate++;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	@Override
	public String toString() {
		return "Account [balance is " + balance + ", accHolder is " + accHolder + "]";
	}
	
	
	 
}

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class TestHashMapDemo {

	public static void main(String[] args) {
		HashMap<Long,String> directory=new HashMap<Long,String>();
		
		directory.put(8859925686L, "Sam");
		directory.put(9998887774L, "Ram");
		directory.put(8563215896L, "Anjali");
		directory.put(8998653241L, "Reena");
		directory.put(8859925686L, "Sa");
		
		
		
		System.out.println(directory);
		
		Set<Map.Entry<Long,String>> mapSet=directory.entrySet();
		Iterator<Map.Entry<Long,String>> it=mapSet.iterator();
		
		while(it.hasNext())
		{
			Map.Entry<Long,String> entry=it.next();
			System.out.println("Key : " +entry.getKey()+"| Name :"+entry.getValue());
		}
		
		System.out.println("-----KeySet---------------");
		
		Set<Long> keys=directory.keySet();
		for(Long key:keys)
		{
			System.out.println(key);
		}
		
		
System.out.println("-----Values-------------");
		
		Collection<String> values=directory.values();
		for(String value:values)
		{
			System.out.println(value);
		}
		
	}
	
	
	

}

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class TestTreeSetDemo {

	public static void main(String[] args) {
		TreeSet<Integer> intList=new TreeSet<Integer>();
		Integer i1=new Integer(10);
		Integer i2=new Integer(10);
		Integer i3=new Integer(30);
		Integer i4=new Integer(20);
		Integer i5=new Integer(40);
		String i6=new String("Heap");
		
		intList.add(i1);
		intList.add(i2);
		intList.add(i3);
		intList.add(i4);
		intList.add(i5);
		//intList.add(i6);
		
		Iterator<Integer> it=intList.iterator();
		while(it.hasNext())
		{
			System.out.println("Entry :" +it.next());
		}

	}

}

package com.capgemini.assignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Second {

	public static void main(String[] args) throws FileNotFoundException {
		
		File text = new File("D://157754 Vivek Uniyal//JavaProjectFolder//FileIO8.1//src//com//capgemini//assignment//numbers.txt");
	      
        
        Scanner sc = new Scanner(text);




		String input=sc.nextLine();
		String[] numbers=input.split(",");
		
		
		int i=0;
		
		while(i<numbers.length)
		{
			if(Integer.parseInt(numbers[i])%2==0)
				System.out.println(Integer.parseInt(numbers[i]) +" is Even Number");
			else
				System.out.println(Integer.parseInt(numbers[i])+" is odd Number");
		
		i++;
		}
		
		
	}

}

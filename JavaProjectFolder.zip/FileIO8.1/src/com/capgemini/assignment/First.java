package com.capgemini.assignment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class First {

	public static void main(String[] args) {
		
		File myFile=new File("D://157754 Vivek Uniyal//JavaProjectFolder//FileIO8.1//src//Input.txt");
		FileReader fr=null;
		FileWriter fw=null;
		BufferedWriter bw=null;
		BufferedReader br=null;
		try 
		{
			fr=new FileReader(myFile);
			br=new BufferedReader(fr);
			
			fw=new FileWriter("Output.txt");
			bw=new BufferedWriter(fw);
			String li=br.readLine();
			StringBuilder line=new StringBuilder(li);
			
			while(li!=null)
			{
				System.out.println(line);
				bw.write(line.reverse().toString());
				bw.flush();
				bw.write("\n");
				bw.flush();
				li=br.readLine();
				if(li!=null)
				line=new StringBuilder(li);
			}
			System.out.println("All data Written");
			
		} catch (IOException e) 
		{
			
			e.printStackTrace();
		}
		
		
		
	}

}

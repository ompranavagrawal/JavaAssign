import org.junit.AfterClass;
import org.junit.*;

public class CalculatorTest {

	static Calculator calc=null;
	@BeforeClass
	public static void setUp()
	{
		calc=new Calculator();
		System.out.println("setUp is called before the execution of all test cases");
	}
	@AfterClass
	public static void tearDown()
	{
		System.out.println("Tear Down is called After the execution of all test cases");
	}
	@Before
	public  void init()
	{
		System.out.println("Init is called before the execution of each test cases");
	}
	@After
	public void destroy()
	{
		System.out.println("Destroy is called after the execution of each test cases");
	}
	@Test
	public void testDivide1()
	{
		Assert.assertEquals(1, calc.divide(100));
		
	}
	@Test
	@Ignore
	public void testDivide2()
	{
		Assert.assertEquals(20, calc.divide(5));
		
	}
	@Test(expected=ArithmeticException.class)
	public void testDivide3()
	{
		Assert.assertEquals(1,calc.divide(0));
	}
}

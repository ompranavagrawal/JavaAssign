import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({CalculatorTest.class,CalculatorTestT.class,HelloWorldTest.class})
public class TestMySuite {
	
	@BeforeClass
	public static void setUpBeforeClass() {
		System.out.println("Now running Test Suite");
	}
	
	@AfterClass
	public static void tearDownAfterClass() {
		System.out.println("The Test Suite is completed");
	}

}

package com.capgemini.junitdemo;

import org.junit.*;

public class ThirdCheck {
static Employee employee=null;

	@BeforeClass
	public static void setUp()
	{
		employee=new Employee();
		employee.setDesignation("Clerk");
		employee.setId(12);
		employee.setInsuranceScheme("Scheme A");
		employee.setName("Ram");
		employee.setSalary(122.5);
		System.out.println("Testing start");
	}
	@AfterClass
	public static void breakDown()
	{
		System.out.println("All done");
	}
	@Test
	public void exceptionTest()
	{
		boolean thrown=false;
		try {
		
			Third.check(employee);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			thrown=true;
			//Assert.assertEquals(employee.getSalary()+" is below 3000", e);
			
		}
		
		Assert.assertTrue(thrown);
	}
	
	
}

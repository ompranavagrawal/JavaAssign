package com.capgemini.junitdemo;
import com.capgemini.*;


public class Third {

	public static void main(String[] args) {
		
		Employee employee=new Employee(11, "AAA", 2000, "Manager", "SchemeA");
		try{
			check(employee);
		}
		catch(EmployeeException e)
		{
			System.out.println(e.toString());
		}
		finally
		{
			System.out.println("Remaining Statements here");
		}
	}

	static void check(Employee employee) throws EmployeeException{
		if(employee.getSalary()<3000)
			throw new EmployeeException(employee.getSalary());
		
	}

}

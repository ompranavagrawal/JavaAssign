import java.io.BufferedReader;
import java.io.*;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TestFileReadLineDemo {

	public static void main(String[] args) {
		File myFile=new File("D://157754 Vivek Uniyal//JavaProjectFolder//DemoFileIOProject//src//TestEmployeeReadDemo.java");
		FileReader fr=null;
		
		FileWriter fw=null;
		
		BufferedWriter bw=null;
		
		
		BufferedReader br=null;
		try 
		{
			fr=new FileReader(myFile);
			br=new BufferedReader(fr);
			
			fw=new FileWriter("MyFile.txt");
			bw=new BufferedWriter(fw);
			String line=br.readLine();
			
			while(line!=null)
			{
				System.out.println(line);
				bw.write(line);
				bw.flush();
				bw.write("\n");
				bw.flush();
				line=br.readLine();
			}
			System.out.println("All data Written");
			
		} catch (IOException e) 
		{
			
			e.printStackTrace();
		}
		
	}

}

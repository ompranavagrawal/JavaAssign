import java.io.FileNotFoundException;
import java.io.*;
import java.util.Scanner;

public class TestEmployeeSerializationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Emp id");
		int eid=sc.nextInt();
		System.out.println("Enter Emp Name");
		String ename=sc.next();
		System.out.println("Enter Emp Salary");
		float esal=sc.nextFloat();
		
		Employee e1=new Employee(eid,ename,esal);
		Employee e2=new Employee(eid,"Ram",esal);
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		
		try {
			fos=new FileOutputStream("EmployeeObj.obj");
			oos=new ObjectOutputStream(fos);
			oos.writeObject(e1);
			oos.writeObject(e2);
			System.out.println("Employee e1 is written");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		

	}

}

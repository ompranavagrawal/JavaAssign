import java.io.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class TestFileReadDemo {

	public static void main(String[] args) {
		
		File myFile=new File("D://157754 Vivek Uniyal//JavaProjectFolder//DemoFileIOProject//src//TestEmployeeReadDemo.java");
		FileInputStream fis;
		try 
		{
			fis=new FileInputStream(myFile);
			int data=fis.read();
			
			while(data!=-1)
			{
				System.out.print((char)data);
				data=fis.read();
			}
			
			
		} catch (IOException e) 
		{
			
			e.printStackTrace();
		}
		

	}

}

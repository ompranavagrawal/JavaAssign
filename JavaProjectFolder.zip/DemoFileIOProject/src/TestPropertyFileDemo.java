import java.io.*;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;


public class TestPropertyFileDemo {

	public static void main(String[] args) {
		FileInputStream fis=null;
		Properties myProp=null;
		try {
			fis=new FileInputStream("UserInfo.properties");
			myProp=new Properties();
			myProp.load(fis);
			
			String unm=myProp.getProperty("userid");
			String pwd=myProp.getProperty("password");
			System.out.println("Credentials : "+unm+" : "+pwd);
			
			System.out.println("--------------------------");
			
			Set<Object> kS=myProp.keySet();
			
			Iterator it=kS.iterator();
			while(it.hasNext())
			{
				System.out.print(" :" + it.next());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

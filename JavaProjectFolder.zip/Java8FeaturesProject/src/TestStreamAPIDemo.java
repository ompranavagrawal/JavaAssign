import java.util.Arrays;
import java.util.stream.Stream;
import java.util.*;

public class TestStreamAPIDemo {
	public static void main(String args[])
	{
		List<Integer> intList=Arrays.asList(45,8,10,3,89,456,10);
		Stream<Integer> intListStream=intList.stream();
		intListStream
		.filter((num)->num>10)
		.forEach(System.out::println);
		
		System.out.println("*******Print Distinct*********");
		intList.stream()
		.distinct()
		.forEach(System.out::println);
		List<String> cityList=Arrays.asList("Pune","Mumbai","","Delhi","Noida","");
		
		
		
		System.out.println("****************");
		cityList.stream()
		.map(str->str.length())
		.forEach(System.out::println);
		
		System.out.println("****************");
		int countOfEmptyString=(int) cityList.stream()
		.filter(str->str.length()==0)
		.count();
		System.out.println(""+countOfEmptyString);
		
	}
}

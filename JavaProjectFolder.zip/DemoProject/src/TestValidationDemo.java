import java.util.*;
import java.util.regex.Pattern;

public class TestValidationDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name");
		String eName=sc.next();
		String namePattern1="[A-Z]*[a-z]+";
		String namePattern2="[0-9]+";
		System.out.println("Entered name is "+eName);
		if(Pattern.matches(namePattern1, eName))
		{
			System.out.println("Valid");
		}
		else
		{
			System.out.println("Not Valid");
		}

	}

}

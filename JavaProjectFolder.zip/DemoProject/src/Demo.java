import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no. of employees");
		int empCount=sc.nextInt();
		
		Employee emps[]=new Employee[empCount];
		for(int i=0;i<empCount;i++)
		{
			System.out.println("Enter employee Name:");
			String name=sc.next();
			System.out.println("Enter Designation :");
			String designation=sc.next();
			System.out.println("Enter Employee Id :");
			int id=sc.nextInt();
			
			System.out.println("Enter Salary :");
			double salary=sc.nextDouble();
			
			System.out.println("Enter insurance scheme:");
			String insuranceScheme=sc.next();
			
			emps[i]=new Employee(id, name, salary, designation, insuranceScheme);
		}
		
		for(Employee emp:emps)
		{
			System.out.println(emp);
		}
		
	}

}

package com.capgemini.fundamentals;
class Person{
	private String firstName;
	private String lastName;
	private char gender;
	private int age;
	private float weight;
	public Person(String firstName, String lastName, char gender, int age, float weight) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
	}
	public Person() {
	
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
	
	
	void display()
	{
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println();
		System.out.println("First Name : "+firstName);
		System.out.println("Last Name : "+lastName);
		System.out.println("Gender : "+gender);
		System.out.println("Age : "+age);
		System.out.println("Weight : "+weight);
	}
	
	
	
}
public class First {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person person=new Person();
		person.setFirstName("Divya");
		person.setLastName("Bharathi");
		person.setAge(20);
		person.setGender('F');
		person.setWeight(85.55f);
		person.display();

	}

}

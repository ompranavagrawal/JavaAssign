import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpDeleteDemo {

	public static void main(String[] args) {
Connection con;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee id to delete:");
		int empId=sc.nextInt();
		String query="delete from emp_157754 where emp_id=?";
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(
					"jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","Lab1btrg21","lab1boracle");
			
			PreparedStatement pst=con.prepareStatement(query);
			pst.setInt(1,empId);
			
			int data=pst.executeUpdate();
			if(data!=0)
			System.out.println("Data Deleted successfully");
			
		}
		catch (ClassNotFoundException |SQLException e) {
			
			e.printStackTrace();
		}

	}

}

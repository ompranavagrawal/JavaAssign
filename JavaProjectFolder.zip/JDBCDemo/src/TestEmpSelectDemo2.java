import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TestEmpSelectDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Connection con;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter min sal :");
		int minSal=sc.nextInt();
		System.out.println("Enter max sal :");
		int maxSal=sc.nextInt();
		
		
		String query="Select * from emp_157754 "
				+ "where emp_salary>=? and emp_salary<=?";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(
					"jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","Lab1btrg21","lab1boracle");
			
			
			PreparedStatement pst=con.prepareStatement(query);
			pst.setInt(1,minSal);
			pst.setInt(2,maxSal);
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			System.out.println(" : " +rs.getInt("emp_id")+
					" : " +rs.getString("emp_name")+
					" : " +rs.getFloat("emp_salary"));
			
			
			con.close();
			
			
			
		} catch (ClassNotFoundException |SQLException e) {
			
			e.printStackTrace();
		}

	
	}
		
		
	}



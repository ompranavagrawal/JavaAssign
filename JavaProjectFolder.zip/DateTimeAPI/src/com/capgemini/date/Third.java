package com.capgemini.date;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Third {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Expiry Date of product is " +input());
		

	}
	static LocalDate input()
	{
		LocalDate enteredDate = null;
		LocalDate expiryDate = null;
		try{
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter purchase date of product in dd/MM/yyyy format:");
			String input  = scanner.nextLine();
			enteredDate = LocalDate.parse(input,formatter);
			System.out.println("------------Enter warrantee period-------");
			System.out.println("Months :");
			int months=scanner.nextInt();
			System.out.println("Year :");
			int year=scanner.nextInt();
			expiryDate=enteredDate.plusMonths(months);
			
			expiryDate=expiryDate.plusYears(year);
		
		}
			catch(Exception e)
			{
				System.out.println("Please enter the date in mentioned format only...");
				
			}
		return expiryDate;
	}

}

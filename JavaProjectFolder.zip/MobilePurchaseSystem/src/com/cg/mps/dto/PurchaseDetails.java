package com.cg.mps.dto;

import java.time.LocalDate;

public class PurchaseDetails {
	private int purchaseId;
	private String cName="";
	private String emailId="";
	private String phoneNo="";
	private LocalDate purchaseDate=LocalDate.now();
	private int mobileId;

	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public PurchaseDetails( String cName,String emailId, String phoneNo, LocalDate purchaseDate,int mobileId) {
		super();
		this.cName = cName;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.emailId=emailId;
		this.mobileId=mobileId;
	}
	public PurchaseDetails() {

	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId is " + purchaseId + ", cName is " + cName + ", emailId is " + emailId
				+ ", phoneNo is " + phoneNo + ", purchaseDate is " + purchaseDate + ", mobileId is " + mobileId + "]";
	}
	

}

package com.cg.mps.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.mps.dto.Mobiles;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.MobileException;
import com.cg.mps.util.DBUtil;

public class MobileDaoImpl implements MobileDao {


	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public int purchaseMobile(PurchaseDetails purchaseDetail) throws MobileException {
		try {
			con=DBUtil.getConn();
			
			String query="insert into purchasedetails_157754 (purchase_id,cname,mailid,phoneno,purchasedate,mobile_id) values(mobile_seq.nextval,?,?,?,?,?)";
			pst=con.prepareStatement(query);
			pst.setString(1,purchaseDetail.getcName());
			pst.setString(2,purchaseDetail.getEmailId());
			pst.setString(3,purchaseDetail.getPhoneNo());
			pst.setString(4,purchaseDetail.getPurchaseDate().getDayOfMonth()+"/"+purchaseDetail.getPurchaseDate().getMonth()+"/"+purchaseDetail.getPurchaseDate().getYear());
			pst.setInt(5,purchaseDetail.getMobileId());
			
			
			return pst.executeUpdate();
		} catch (Exception e) {
			throw new MobileException(e.getMessage());
		}
		finally 
		{
			try {
				con.close();
				rs.close();
				pst.close();
			}
			catch (Exception e)
			{
				throw new MobileException(e.getMessage());
			}
		}

	}

	@Override
	public ArrayList<Mobiles> allMobiles()  throws MobileException {
		ArrayList<Mobiles> mobileList=new ArrayList<Mobiles>();

		try {
			con=DBUtil.getConn();
			st=con.createStatement();
			String query="select * from mobiles_157754";
			rs=st.executeQuery(query);
			while(rs.next())
			{
				mobileList.add(new Mobiles(rs.getInt(1), rs.getString(2), rs.getFloat(3), rs.getString(4)));
			}


			return mobileList;	
		} catch (Exception e) {
			throw new MobileException(e.getMessage());
		}
		finally {
				try {
				con.close();
				rs.close();
				st.close();
					}
				catch(Exception e)
					{
				throw new MobileException(e.getMessage());
					}
				}



	}

	@Override
	public int deleteMobileDetail(int mobId) throws MobileException{
		try {
			con=DBUtil.getConn();
			String query="delete from mobiles_157754 where mobile_id=?";
			String query2="delete from purchasedetails_157754 where mobile_id=?";
			pst=con.prepareStatement(query2);
			pst.setInt(1,mobId);
			pst.executeUpdate();
			
			pst=con.prepareStatement(query);
			pst.setInt(1,mobId);
			return pst.executeUpdate();
		} catch (Exception e) {
			throw new MobileException(e.getMessage());
		}
		finally 
		{
			try {
				con.close();
				rs.close();
				pst.close();
			}
			catch (Exception e)
			{
				throw new MobileException(e.getMessage());
			}
		}
	}

	@Override
	public ArrayList<Mobiles> searchMobile(int minPrice, int maxPrice) throws MobileException{
		ArrayList<Mobiles> mobileList=new ArrayList<Mobiles>();
		try {
			con=DBUtil.getConn();
			String query="select * from mobiles_157754 where price>=? and price<=?";
			pst=con.prepareStatement(query);
			pst.setFloat(1,minPrice);
			pst.setFloat(2,maxPrice);
			rs=pst.executeQuery();
			while(rs.next())
			{
				mobileList.add(new Mobiles(rs.getInt(1), rs.getString(2), rs.getFloat(3), rs.getString(4)));
			}


			return mobileList;		
		} catch (Exception e) {
			throw new MobileException(e.getMessage());
		}
		finally {
				try {
				con.close();
				rs.close();
				
					}
				catch(Exception e)
					{
				throw new MobileException(e.getMessage());
					}
				}

	}

	@Override
	public int quantityMobile(int mobileId) throws MobileException {
		try {
			con=DBUtil.getConn();
			
			String query="select * from mobiles_157754 where mobile_id=?";
			pst=con.prepareStatement(query);
			pst.setInt(1,mobileId);
			rs=pst.executeQuery();
			System.out.println("haha");
			if(rs.next())
				return rs.getInt("quantity");
			else
				return 0;
			
		} catch (Exception e) {
			throw new MobileException(e.getMessage());
		}
		finally {
				try {
				con.close();
				rs.close();
				pst.close();
					}
				catch(Exception e)
					{
				throw new MobileException(e.getMessage());
					}
				}
	}

	@Override
	public int updateMobileQuantity(int mobileId,int quantity) throws MobileException {
		try {
			con=DBUtil.getConn();
			String query="update mobiles_157754 set quantity=? where mobile_id=?";
			pst=con.prepareStatement(query);
			pst.setInt(1,quantity);
			pst.setInt(2,mobileId);
			
			return pst.executeUpdate();
			
		} catch (Exception e) {
			throw new MobileException(e.getMessage());
		}
		finally 
		{
			try {
				con.close();
				pst.close();
			}
			catch (Exception e)
			{
				throw new MobileException(e.getMessage());
			}
		}
	}

}

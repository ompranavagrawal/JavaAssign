package com.cg.mps.service;

import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.mps.dao.MobileDao;
import com.cg.mps.dao.MobileDaoImpl;
import com.cg.mps.dto.Mobiles;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.MobileException;

public class MobileServiceImpl implements MobileService {
	MobileDao mobileDao=null;
	public MobileServiceImpl() {
		mobileDao=new MobileDaoImpl();
	}
	@Override
	public int purchaseMobile(PurchaseDetails purchaseDetail) throws MobileException {
		int quantity=mobileDao.quantityMobile(purchaseDetail.getMobileId());
		if(quantity>0)
		{
		
			int purchase=mobileDao.purchaseMobile(purchaseDetail);
			if(purchase==1) {
				System.out.println(quantity);
				mobileDao.updateMobileQuantity(purchaseDetail.getMobileId(), quantity-1);
				System.out.println("new "+mobileDao.quantityMobile(purchaseDetail.getMobileId()));
				return 1;
			}
			else {
				return 0;
			}
			
		}
		else
		{
		return 0;
		}
	
	}

	@Override
	public ArrayList<Mobiles> allMobiles() throws MobileException {
		// TODO Auto-generated method stub
		return mobileDao.allMobiles();
	}

	@Override
	public int deleteMobileDetail(int mobId) throws MobileException {
		
		return mobileDao.deleteMobileDetail(mobId);
	}

	@Override
	public ArrayList<Mobiles> searchMobile(int minPrice, int maxPrice) throws MobileException {
		
		return mobileDao.searchMobile(minPrice, maxPrice);
	}

	@Override
	public boolean validateCustName(String cName) throws MobileException {
		
		String namePattern="[A-Z][a-z]{0,19}";
		if(Pattern.matches(namePattern, cName))
			return true;
		else
			throw new MobileException("Invalid Customer name. "
					+ "Should start with capital"
					+ " Only characters are allowed with maximum lenght 20");
		
	
	}

	@Override
	public boolean validateMobileNo(String phoneNo) throws MobileException {
		String phonePattern="[1-9][0-9]{9}";
		if(Pattern.matches(phonePattern, phoneNo))
			return true;
		else
			throw new MobileException("Invalid Mobile Number. "
					+ "1st digit cannot be '0' "
					+ " Only numbers are allowed with maximum lenghth 10");
	}

	@Override
	public boolean validateEmailId(String emailId) throws MobileException {
		String emailPattern="[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}";
		if(Pattern.matches(emailPattern, emailId))
			return true;
		else
			throw new MobileException("Invalid Email Id.");
	}

	@Override
	public boolean validateMobileId(int mobileId) throws MobileException {
		ArrayList<Mobiles> allMobiles=mobileDao.allMobiles();
		if(allMobiles!=null) 
		{
			for(Mobiles mobile:allMobiles)
			{
			if(mobile.getMobileId()==mobileId)
				return true;
			}
			
		}
		else
			throw new MobileException("Mobile Id does not match. ");
		return false;
		}
		
	}



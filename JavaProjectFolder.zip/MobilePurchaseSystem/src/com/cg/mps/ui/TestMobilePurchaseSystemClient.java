package com.cg.mps.ui;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mps.dto.Mobiles;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.MobileException;
import com.cg.mps.service.MobileService;
import com.cg.mps.service.MobileServiceImpl;

public class TestMobilePurchaseSystemClient {
	static MobileService mobileService=null;
	static Scanner sc=new Scanner(System.in);
	static Logger logger=Logger.getLogger(TestMobilePurchaseSystemClient.class);
	
	private static void showMenu()
	{
		System.out.println("______________________________");
		System.out.println("    MOBILE PURCHASE SYSTEM");
		System.out.println("______________________________");
		System.out.println("1. Purchase Mobile");
		System.out.println("2. View Details of all Mobiles");
		System.out.println("3. Delete Mobile");
		System.out.println("4. Search mobiles");
		System.out.println("5. Show purchases");
		System.out.println("6. Exit");
		System.out.println("Enter Your Choice :");
	}
	
	
	public static void main(String[] args) {
		mobileService=new MobileServiceImpl();
		PropertyConfigurator.configure("D:\\157754 Vivek Uniyal\\JavaProjectFolder\\MobilePurchaseSystem\\resources\\log4j.properties");
		logger.info("New Session");
		while(true)
		{
			showMenu();
			int ch=sc.nextInt();
			switch(ch)
			{
			case 1:logger.info("Mobile purchase module is called"); purchaseMobile();
					logger.info("Purchase module completed");break;
			case 2: logger.info("Mobile Details module is called");detailsAllMobile();
					logger.info("MobileDetails module completed");break;
			case 3: logger.info("Delete module is called");deleteMobile();
					logger.info("Delete module completed");break;
			case 4: logger.info("Search module is called");searchMobile();
					logger.info("search module completed");break;
			case 6:logger.info("Application Closed");System.exit(0);
			case 5:logger.info("Show Purchases is called"); showPurchase();logger.info("Show purchases is completed");
			default:System.out.println("Invalid input");
			
			}
			
		}
		}
		

	


	private static void showPurchase() {
		// TODO Auto-generated method stub
		
	}


	private static void searchMobile() {
		System.out.println("-----------Search Mobiles here----------");
		System.out.println();
		try
		{
		System.out.println("Enter minimum price");
		int minPrice=sc.nextInt();
		System.out.println("Enter maximum price");
		int maxPrice=sc.nextInt();
		ArrayList<Mobiles> mobileList=mobileService.searchMobile(minPrice, maxPrice);
		
		if(mobileList!=null)
		{
			System.out.println("MobileID \t Name \t Price \t Quantity");
			System.out.println("------------------------------------------");
			System.out.println();
			for(Mobiles mobile:mobileList)
			{
				System.out.println(mobile.getMobileId()+" \t "+mobile.getName()+" \t "
						+mobile.getPrice()+" \t "+mobile.getQuantity());
			}
		}
		else
		{
			System.out.println("No Match Found");
		}
		
		
		
		}
		catch(MobileException e)
		{
			logger.error(e.getMessage());
			e.printStackTrace();
		}
	}


	private static void deleteMobile() {
		try
		{
			System.out.println("---------Delete Mobile Details Here---------");
			System.out.println();
			System.out.println("Enter mobile Id :");
			int mobileId=sc.nextInt();
			if(mobileService.validateMobileId(mobileId))
			{
				int status=mobileService.deleteMobileDetail(mobileId);
				if(status==1)
					System.out.println(mobileId+" Successfully Deleted");
				else
					System.out.println("Some issues with deletion");
			}
			
		}
		catch(MobileException e)
		{
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		
	}


	private static void detailsAllMobile()  {
		System.out.println("-----------Mobiles Available--------------");
		try {
			ArrayList<Mobiles> mobileList=mobileService.allMobiles();
			if(mobileList!=null)
			{
				
				System.out.println("MobileID \t Name \t Price \t Quantity");
				System.out.println("------------------------------------------");
				System.out.println();
				for(Mobiles mobile:mobileList)
				{
					System.out.println(mobile.getMobileId()+" \t "+mobile.getName()+" \t "
							+mobile.getPrice()+" \t "+mobile.getQuantity());
				}
			}
			else
			{
				System.out.println("Currently, No Mobiles available");
			}
			
		} catch (MobileException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		
	}


	private static void purchaseMobile() {
		try {
			
		detailsAllMobile();
		System.out.println("Enter Customer Name");
		String cName=sc.next();
		if(mobileService.validateCustName(cName)) {
			
	
		System.out.println("Enter emailId");
		String emailId=sc.next();
		if(mobileService.validateEmailId(emailId))
		{
		System.out.println("Enter phone No");
		String phoneNo=sc.next();
		if(mobileService.validateMobileNo(phoneNo))
		{
		
		System.out.println("Enter Mobile Id");
		int mobileId=sc.nextInt();
		if(mobileService.validateMobileId(mobileId))
		{
			LocalDate purchaseDate=LocalDate.now();
			PurchaseDetails purchaseDetail=new PurchaseDetails(cName, emailId, phoneNo, purchaseDate, mobileId);
			int status=mobileService.purchaseMobile(purchaseDetail);
			if(status==1)
				System.out.println("Purchase Made");
			else
				System.out.println("Some issue with purchase");
		}
		
		}
		}
	}
		}
		catch(MobileException e)
		{logger.error(e.getMessage());
			e.printStackTrace();
		}
		
		
		
	}
	

}
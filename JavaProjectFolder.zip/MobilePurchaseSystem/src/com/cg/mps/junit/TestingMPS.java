package com.cg.mps.junit;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;

import com.cg.mps.dao.MobileDaoImpl;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.MobileException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
@RunWith(Parameterized.class)
public class TestingMPS {

	@Test(expected=MobileException.class)
	public void testInsert() throws MobileException
	{
		PurchaseDetails purchase=new PurchaseDetails();
		MobileDaoImpl mobile=new MobileDaoImpl();
		Assert.assertEquals(1, mobile.purchaseMobile(purchase));
	}
	
	
	
	
}

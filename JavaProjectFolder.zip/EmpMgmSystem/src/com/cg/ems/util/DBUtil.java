package com.cg.ems.util;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
public class DBUtil 
{
	static String driver=null;
	static String url=null;
	static String unm=null;
	static String pwd=null;

	public static Connection getConn() throws SQLException, IOException, ClassNotFoundException {
		Properties myProp=loadDBInfo();
		driver=myProp.getProperty("dbDriver");
		url=myProp.getProperty("dbUrl");
		unm=myProp.getProperty("dbUser");
		pwd=myProp.getProperty("dbPassword");
		Connection con=null;
		//Class.forName(driver);
		if(con==null)
		{
			
			con=DriverManager.getConnection(url,unm,pwd);
		}
		return con;
		
	}
	public static Properties loadDBInfo() throws IOException
	{
		FileReader fr=new FileReader("dbInfo.properties");
		Properties dbProp=new Properties();
		dbProp.load(fr);
		return dbProp;
	}
	
}

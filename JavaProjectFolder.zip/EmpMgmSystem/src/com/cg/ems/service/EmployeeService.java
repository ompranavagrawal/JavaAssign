package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public interface EmployeeService {
	public ArrayList<Employee> getAllEmployee() throws EmployeeException;
	public int addEmployee(Employee employee) throws EmployeeException;
	public boolean validateEmpName(String eName) throws EmployeeException;
}

package arrays_collectionAssignmenytPack3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

public class ArrayListSort7_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> productName=new ArrayList<String>();
		String i1=new String("Pen");
		String i2=new String("Pencil");
		String i3=new String("Rubber");
		String i4=new String("NoteBook");
		
		
		productName.add(i1);
		productName.add(i2);
		productName.add(i3);
		productName.add(i4);
		
		Collections.sort(productName);
		
		System.out.println("After sorting");
		Iterator<String> it=productName.iterator();
		while(it.hasNext()) {
			String ii=it.next();
			System.out.println(ii.toString());
		}
		
	}

}



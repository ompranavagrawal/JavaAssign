package dateTimePack2;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
public class Q2 {


	public static void main(String[] args) {
		
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter first date in dd/MM/yyyy format:");
		String input1  = scanner.nextLine();
			
		LocalDate enteredDate1 = LocalDate.parse(input1,formatter);

		System.out.print("Enter Second date in dd/MM/yyyy format:");
		String input2  = scanner.nextLine();
			
		LocalDate enteredDate2 = LocalDate.parse(input2,formatter);
			
		scanner.close();
			
		Period period = enteredDate1.until(enteredDate2);
		
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
			
		
	}

}




 


package dateTimePack2;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class Q5 {

	public static Period CalculateAge(Person p) {
		
		LocalDate Age=p.getDOB();
		LocalDate end = LocalDate.now();
		
		Period period = Age.until(end);
		
		return period;
		
	}
	public static String GetFullDetails(Person p) {
		
		String fullName=p.getFirstName();
		String lastName=p.getLastName();
		LocalDate Age=p.getDOB();
		
		return fullName+" "+lastName+" "+CalculateAge(p).getYears();
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person P1=new Person();
		P1.setFirstName("Pranav");
		P1.setLastName("Agrawal");
		P1.setGender('M');
		P1.setDOB(LocalDate.of(1996,Month.OCTOBER,25));
		
		Period age=CalculateAge(P1);
		
		System.out.println(GetFullDetails(P1));
	}

}

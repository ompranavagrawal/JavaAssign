package dateTimePack2;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
public class Q3 {


	public static void main(String[] args) {
		
		try {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter purchase date in dd/MM/yyyy format:");
		String purDate  = scanner.nextLine();
		LocalDate L1 = LocalDate.parse(purDate,formatter);
		
		System.out.print("Enter Months of warrantee:");
		int EnteredMonth  = scanner.nextInt();
				
		System.out.print("Enter year of warrantee:");
		int EnteredYear  = scanner.nextInt();
					
		scanner.close();

		LocalDate L2=L1.plusMonths(EnteredMonth);
		System.out.println("warrantee of product expires on:"+ L2.plusYears(EnteredYear));
		}
		catch(Exception e) {
			System.out.println("Enter the correct Date Format");
		}
			
		
	}

}
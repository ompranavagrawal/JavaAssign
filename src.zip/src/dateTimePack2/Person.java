package dateTimePack2;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Person {
	
	String firstName;
	String lastName;
	char gender;
	LocalDate DOB;
	public Person(String firstName, String lastName, char gender, LocalDate enteredDate) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.DOB = DOB;
	}




	public String getFirstName() {
		return firstName;
	}




	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}




	public String getLastName() {
		return lastName;
	}




	public void setLastName(String lastName) {
		this.lastName = lastName;
	}




	public char getGender() {
		return gender;
	}




	public void setGender(char gender) {
		this.gender = gender;
	}




	public LocalDate getDOB() {
		return DOB;
	}




	public void setDOB(LocalDate DOB) {
		this.DOB = DOB;
	}

	

	
	
	public Person() {
		// TODO Auto-generated constructor stub
	}

}

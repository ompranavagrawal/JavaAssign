package dateTimePack2;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;
public class Q4 {



	public static void main(String[] args) {
		
		try {
		System.out.println("Enter ZoneID:");
		Scanner scanner = new Scanner(System.in);
		String EnteredZone  = scanner.nextLine();
		ZonedDateTime currentTime = ZonedDateTime.now();
		ZonedDateTime currentTimeInZone = currentTime.withZoneSameInstant(ZoneId.of(EnteredZone));
		System.out.println(currentTimeInZone);
		}
		catch(Exception e) {
			System.out.println("Enter zoneID in correct format");
		}
		
		
		

	}

}

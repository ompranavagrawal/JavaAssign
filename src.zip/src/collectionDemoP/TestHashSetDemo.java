package collectionDemoP;
import java.util.HashSet;
import java.util.Iterator;

import arraysPack3.Emp;

public class TestHashSetDemo {

	public static void main(String[] args) {
		HashSet<Integer> intSet=new HashSet<Integer>(4);//ordered and not add duplicate
		
		System.out.println("Size : "+intSet.size());
		
		Integer e1=new Integer(1111);
		Integer e2=new Integer(1122);
		Integer e3=new Integer(1333);
		Integer e4=new Integer(4444);
		Integer e5=new Integer(1111);
		
		System.out.println("Size : "+intSet.size());
		
		intSet.add(e1);
		intSet.add(e2);
		intSet.add(e3);
		intSet.add(e4);
		intSet.add(e5);
		
		System.out.println("Size : "+intSet.size());
		
		Iterator<Integer> it=intSet.iterator();
		while(it.hasNext()) {
			Integer kk=90;
			Integer ii=it.next();
			System.out.println("Entry->  "+ii);
		}

	}

}


package pack1;

import arraysPack3.Emp;

public class Employee implements Comparable<Employee> {
	
	int Id;
	

	String name;
	Double salary;
	String designation;
	String insuranceSceme;
	public Employee(int eid, String name, Double salary, String designation, String insuranceSceme) {
		super();
		this.Id = eid;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.insuranceSceme = insuranceSceme;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceSceme() {
		return insuranceSceme;
	}
	public void setInsuranceSceme(String insuranceSceme) {
		this.insuranceSceme = insuranceSceme;
	}
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	
	/*@Override                            
	public int hashCode() {
		
		
		return salary;
	}*/
	

	@Override 
	public int compareTo(Employee ee) {
		if((this.salary)<(ee.salary)) {
			return -1;
		}
		else if((this.salary)==(ee.salary)) {
			return 0;
		}
		else {
			return +1;
		}
	}
	
	
	@Override
	public String toString() {
		return "Employee [Id=" + Id + ", name=" + name + ", salary=" + salary + ", designation=" + designation
				+ ", insuranceSceme=" + insuranceSceme +"]"+"\n";
	}
	
	
}

package pack1;
class AgeException extends Exception {
    
	AgeException() {
     
     }
	AgeException(String args) {
		super(args);
	 }
     public String toString()      {
        return "AgeException";
     }
}
public class Person1Main {
	
	public static void main(String[] args) throws AgeException {
		// TODO Auto-generated method stub
		Person1 P1=new Person1();
		float age=2;
		String name="Pranav";
		try {
			
			P1.setName(name);
			checkAge(age);
			P1.setAge(age);
		}
		catch(AgeException e)
		{
			System.out.println("Exception occured "+e);
		}
		finally {
			System.out.println("normal execution");
			System.out.println(P1.Name);
			System.out.println(P1.Age);
		}
	}
	
	static void checkAge(float a) throws AgeException {
		if(a<15) {
			System.out.println("Age less than 15");
			throw new AgeException();
		}
	}
	
}

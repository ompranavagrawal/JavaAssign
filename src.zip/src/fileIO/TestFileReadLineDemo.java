package fileIO;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TestFileReadLineDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File myFile=new File("D://Pranav//PranavProj//src//fileIO//TestEmpReadDemo.java");
		FileReader fr = null;
		BufferedReader br=null;
		try {
			fr =new FileReader(myFile);
			br=new BufferedReader(fr);
			String line=br.readLine();
			
			while (line!=null) {
				System.out.println(line);
				line=br.readLine();
				
			}
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

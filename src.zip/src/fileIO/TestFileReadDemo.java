package fileIO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class TestFileReadDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File myFile=new File("D://Pranav//PranavProj//src//fileIO//TestEmpReadDemo.java");
		FileInputStream fis = null;
		try {
			fis =new FileInputStream(myFile);
			int data=fis.read();
			while (data!=-1) {
				System.out.print((char)data);
				data=fis.read();
				
			}
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

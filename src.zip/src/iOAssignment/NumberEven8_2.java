package iOAssignment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class NumberEven8_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File myFile=new File("numbers.txt");
		FileInputStream fis = null;
		String str="";
		try {
			Scanner sc =new Scanner(new File("numbers.txt"));
			while(sc.hasNext()) {
				str=sc.nextLine();
			}
			//System.out.println(str);
			String [] delString= str.split(",");
			for(int i=0;i<delString.length ;i++) {
				if(Integer.parseInt(delString[i])%2==0) {
					System.out.println(delString[i]);
				}
				
			}
		} 
		
		
		catch (IOException e1) {
			
			e1.printStackTrace();
		}		
		 
		
	}

}

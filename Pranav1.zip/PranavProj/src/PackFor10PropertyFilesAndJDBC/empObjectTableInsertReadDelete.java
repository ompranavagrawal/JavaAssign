package PackFor10PropertyFilesAndJDBC;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import iOAssignment.Employee;

public class empObjectTableInsertReadDelete {
public static void main(String[] args) {
		
		Connection con = null;
		PreparedStatement pst=null;
		Statement st=null;
		ResultSet rs=null;
		Scanner sc=new Scanner(System.in);
		
		String qry="CREATE TABLE EmpTable(EmpId number,EmpName varchar(20),EmpSal number,Empdes varchar(20),EmpIns varchar(20))";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","Lab1btrg9","lab1boracle");
			pst=con.prepareStatement(qry);
	
			rs=pst.executeQuery();
			System.out.println("Table Created");

			System.out.println("Press 1 to continue");
			int ch=sc.nextInt();
			while(ch==1) {
				System.out.println("Press \n1 to insert data\n2 to delete data\n3 to Display data\n5 to exit");
				int choice=sc.nextInt();
				
				switch (choice) {
				case 1:
					System.out.println("Enter the number of employees");
					int num= sc.nextInt();
					for(int k=0;k<num;k++) {
						System.out.println("Enter Emp ID:");
						int eid=sc.nextInt();
						System.out.println("Enter Emp Name:");
						String enm=sc.next();
						System.out.println("Enter Emp Salary:");
						Double esl=sc.nextDouble();
						System.out.println("Enter Emp Designation:");
						String edes=sc.next();
						System.out.println("Enter Emp Insurance scheme:");
						String eins=sc.next();				
						
						String insertQry="INSERT INTO EmpTable VALUES(?,?,?,?,?)";
						
						Class.forName("oracle.jdbc.driver.OracleDriver");
						con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","Lab1btrg9","lab1boracle");
						pst=con.prepareStatement(insertQry);
						pst.setInt(1, eid);
						pst.setString(2, enm);
						pst.setDouble(3, esl);
						pst.setString(4, edes);
						pst.setString(5, eins);
						
						int noOfRecAffected=pst.executeUpdate();
						System.out.println(noOfRecAffected+" data is inserted in table.");
						
					}
					break;
				case 2:
					System.out.println("Enter the employee id whome you want to delete");
					int delId=sc.nextInt();
					String delQry="DELETE FROM EmpTable WHERE EmpId=?";
					try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","Lab1btrg9","lab1boracle");
						pst=con.prepareStatement(delQry);
						pst.setInt(1, delId);

						int noOfRecAffected=pst.executeUpdate();
						System.out.println(noOfRecAffected+" data is deleted from the table.");
					}
					catch (ClassNotFoundException|SQLException e) {

						e.printStackTrace();
					}
					break;
					
				case 3:

					try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","Lab1btrg9","lab1boracle");
						st=con.createStatement();
						rs=st.executeQuery("SELECT * FROM EmpTable");
						while(rs.next()) {
							System.out.println(" : "+rs.getInt("EmpId")+" : "+rs.getString("EmpName")+" : "+ rs.getInt("EmpSal")+" : "+ rs.getString("Empdes")+" : "+ rs.getString("EmpIns"));
						}
					}
					 catch (ClassNotFoundException e) {
							
							e.printStackTrace();
					}
					catch (SQLException e) {	
						e.printStackTrace();
					}
					break;	
					
				default:
					System.out.println("Enter the correct option");
					break;
				}	

				System.out.println("Press 1 to continue");
				ch=sc.nextInt();	
			}
						
		}	
		catch (ClassNotFoundException |SQLException  e) {
				
				e.printStackTrace();
		}
		
		
	}

}
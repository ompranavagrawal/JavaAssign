package PackFor10PropertyFilesAndJDBC;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
public class propertiesFileStroreAndDisplay8_1 {
/*10.1: Write a program to store a person details in a properties file named as �PersonProps.properties� and also do the following tasks:
a)	Read data from properties file, load the data into Properties object and display the data in the console.
b)	Read data from properties file(using getProperties method) and print data in the console.
*/

	public static void main(String[] args) {
			
			FileOutputStream fos=null;
			Properties myDbInfo=null;
			try 
			{
				fos=new FileOutputStream("PersonProps.properties");
				myDbInfo=new Properties();
				myDbInfo.setProperty("UserName", "Pranav");
				myDbInfo.setProperty("Gender", "M");
				myDbInfo.store(fos, "This is Data base Information.");
				System.out.println("Data is written in the file ");
			} 
			
			catch (IOException e) 
			{
				e.printStackTrace();
			}
			
			FileInputStream fis=null;
			Properties myPros=null;
			try {
				fis=new FileInputStream("PersonProps.properties");
				myPros=new Properties();
				myPros.load(fis);
				String unm=myPros.getProperty("UserName");
				String gen=myPros.getProperty("Gender");
				System.out.println("credentials : " +gen+" : "+unm);
				
				System.out.print("Key Set are->");
				Set kS=myPros.keySet();
				Iterator it=kS.iterator();
				while(it.hasNext()) {
					System.out.print(" : "+it.next());
				}
			} 
			
			catch (IOException e) {
				
				e.printStackTrace();
			}
			
			
		}

}


package arrays_collectionAssignmenytPack3;

import java.util.Arrays;

public class StringArray7_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
/*		Write a program to store product names in a string array and sort strings available in an array. 
*/
		String productName[]=new String[4];
		productName[0]="Pen";
		productName[1]="Pencil";
		productName[2]="Rubber";
		productName[3]="NoteBook";
		Arrays.sort(productName);
		for(int i=0;i<productName.length;i++) {
			System.out.println(productName[i]);
		}
		
	}

}

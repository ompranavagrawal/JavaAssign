package arrays_collectionAssignmenytPack3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import pack1.Employee;
public class EmployeeHashMap7_3 {
	
	static HashMap<String,Employee> EmployeeHashMap = new HashMap<String,Employee>(); //key-> insurance Scheme | value-> Employee object 
	
	public static void addEmployee(Employee emp)	{
		
		EmployeeHashMap.put(emp.getInsuranceSceme(), emp);
	}
	
	public static void displayDetailBasedOnInsurance(String empIns) {
		Employee value=EmployeeHashMap.get(empIns);
		
		System.out.println(value);
	}
	
	
	public static boolean deleteEmployee(String id)	{

		
		Employee toDelete=null;
		int flag=0;
		//hashSet is converted to collection the iterator work the delete work
		Collection<Employee> itValues=EmployeeHashMap.values();
		
		for(Employee emp:itValues) {
			
			if(emp.getId()==Integer.parseInt(id)) {
				toDelete=emp;
				flag=1;
				break;
				
			}
		}
		if(flag==1) {
			EmployeeHashMap.remove(toDelete.getInsuranceSceme(),toDelete);
			return true;
		}
		else
			return false;
	}
	
	

	
	private static void sortEmployeeDetails() {
		Collection<Employee> Values=EmployeeHashMap.values();
		List mylist = new ArrayList<>(Values);
		Collections.sort(mylist);
		System.out.println(EmployeeHashMap);
		
	}
	
	public static void main(String[] args) {
		
		Employee e1=new Employee(1,"Pranav Agrawal",(double) 20000,"Analyst","LIC");
		Employee e2=new Employee(2,"Ram Prasad",(double) 30000,"Analyst","PNB");
		Employee e3=new Employee(3,"Laxman Rao",(double) 40000,"Analyst","SBI");
		Employee e4=new Employee(4,"Sita Gulati",(double) 50000,"Analyst","ICICI");
		addEmployee(e1);
		addEmployee(e2);
		addEmployee(e3);
		addEmployee(e4);

		displayDetailBasedOnInsurance(e2.getInsuranceSceme());
		displayDetailBasedOnInsurance(e3.getInsuranceSceme());
		System.out.println("deleteting employee having ID-> 3");
		
		System.out.println("status-> "+deleteEmployee("3"));
		
		sortEmployeeDetails();
		
		
		
	}

	
	

}




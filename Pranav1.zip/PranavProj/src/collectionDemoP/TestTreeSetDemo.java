package collectionDemoP;

import java.util.Iterator;
import java.util.TreeSet;

public class TestTreeSetDemo {

	public static void main(String[] args) {
		TreeSet<Integer> intSet=new TreeSet<Integer>();//treeSet-> Unique and sorted
		
		System.out.println("Size : "+intSet.size());
		
		Integer e1=new Integer(1111);
		Integer e2=new Integer(1122);
		Integer e3=new Integer(1333);
		Integer e4=new Integer(4444);
		Integer e5=new Integer(1111);
		
		System.out.println("Size : "+intSet.size());
		
		intSet.add(e1);
		intSet.add(e2);
		intSet.add(e3);
		intSet.add(e4);
		intSet.add(e5);
		
		System.out.println("Size : "+intSet.size());
		
		Iterator<Integer> it=intSet.iterator();
		while(it.hasNext()) {
			Integer kk=90;
			Integer ii=it.next();
			System.out.println("Entry->  "+ii);
		}

	}

}

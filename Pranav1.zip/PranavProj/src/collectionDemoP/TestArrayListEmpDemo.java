package collectionDemoP;

import java.util.ArrayList;
import java.util.Iterator;

import arraysPack3.Emp;

public class TestArrayListEmpDemo {

	public static void main(String[] args) {
		ArrayList<Emp> empList=new ArrayList<Emp>();//ordered and add duplicate
		Emp e1=new Emp(1111,"Pranav Agrawal",9000.0F);
		Emp e2=new Emp(1122,"Ram Prasad",9000.0F);
		Emp e3=new Emp(1333,"Laxman Rao",9000.0F);
		Emp e4=new Emp(4444,"Sita Gulati",9000.0F);
		Emp e5=new Emp(1111,"Pranav Agrawal",9000.0F);
		
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		empList.add(e5);
		
		Iterator<Emp> itEmp=empList.iterator();
		while(itEmp.hasNext()) {
			System.out.println(" ...."+itEmp.next());
		}

	}

}

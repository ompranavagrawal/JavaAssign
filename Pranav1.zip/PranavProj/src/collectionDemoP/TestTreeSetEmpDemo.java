package collectionDemoP;

import java.util.Iterator;
import java.util.TreeSet;

import arraysPack3.Emp;

public class TestTreeSetEmpDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Emp> empList=new TreeSet<Emp>();//Random and add duplicate/not unique ,hash code
		Emp e1=new Emp(1111,"Pranav Agrawal",9000.0F);// generated so placed at random places
		Emp e2=new Emp(1122,"Ram Prasad",9000.0F);
		Emp e3=new Emp(1333,"Laxman Rao",9000.0F);
		Emp e4=new Emp(4444,"Sita Gulati",9000.0F);
		Emp e5=new Emp(1111,"Pranav Agrawal",9000.0F);
		
		empList.add(e1);//comparable is used to sort but emp is not comparable
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		empList.add(e5);
		
		Iterator<Emp> itEmp=empList.iterator();
		while(itEmp.hasNext()) {
			System.out.println(" ...."+itEmp.next());

	}

}
}
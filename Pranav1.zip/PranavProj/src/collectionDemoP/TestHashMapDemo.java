package collectionDemoP;
import java.util.Map;

import java.util.Map.Entry;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class TestHashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		HashMap<Long, String> directory=new HashMap<Long, String>();
		//<key,Value>
		
		directory.put(1234567890L, "Pranav Agrawal");
		directory.put(1234567891L, "Ram Prasad");
		directory.put(1234567892L, "Laxman Rao");
		directory.put(1234567893L, "Sita Gulati");
		directory.put(1234567890L, "Hanuman Singh");
		System.out.println(directory);
		System.out.println("*******************Print Only Entries***************");
		Set<Map.Entry<Long,String>> mapSet=directory.entrySet();
		Iterator<Map.Entry<Long, String>> it=mapSet.iterator();
		while(it.hasNext()) {
			Map.Entry<Long, String> entry=it.next();
			System.out.println(" Key :"+entry.getKey()+" Name : "+entry.getValue());
		}
		
		System.out.println("*******************Print Only Keys***************");
		Set<Long> kSet=directory.keySet();
		Iterator<Long> itK=kSet.iterator();
		while(itK.hasNext()) {
			
			Long key=itK.next();
			System.out.println(" : "+key);
	    }
		
		System.out.println("*******************Print Only values***************");
		Collection<String> kValue=directory.values();
		Iterator<String> itV=kValue.iterator();
		while(itV.hasNext()) {
			
			String Value=itV.next();
			System.out.println(" : "+Value);
	    }

	}
}

package iOAssignment;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReversePrint8_1 {

	

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			File myFile=new File("D://Pranav//PranavProj//src//fileIO//TestEmpReadDemo.java");
			FileReader fr = null;
			BufferedReader br=null;
			FileWriter fw = null;
			BufferedWriter bw=null;
			try {
				fr =new FileReader(myFile);
				br=new BufferedReader(fr);
				String line=br.readLine();
				String strRev=line;
				
				
				
				fw=new FileWriter("MyFile1.txt");
				bw=new BufferedWriter(fw);
				
				
				while (line!=null) {
					
					strRev=strRev+"\n"+line;
					line=br.readLine();
					
				}
				
				StringBuilder strRev2=new StringBuilder(strRev);
				String strRev3=new String(strRev2.reverse());
				
				bw.write(strRev3);
				bw.flush();
			} 
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}


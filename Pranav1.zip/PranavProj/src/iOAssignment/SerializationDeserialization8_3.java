package iOAssignment;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;
public class SerializationDeserialization8_3 {
////////////////////////////////////////////////////////////////SERIALIZATION/////////////////////////////
		public static void main(String[] args) {
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter No. of Objects you want to enter:");
			int num=sc.nextInt();
			
			FileOutputStream fos=null;
			
			ObjectOutputStream oos=null;
			try {
			fos=new FileOutputStream("EmpObj1.obj");
			oos=new ObjectOutputStream(fos);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			for(int k=0;k<num;k++) {
			System.out.println("Enter Emp ID:");
			int eid=sc.nextInt();
			System.out.println("Enter Emp Name:");
			String enm=sc.next();
			System.out.println("Enter Emp Salary:");
			Double esl=sc.nextDouble();
			System.out.println("Enter Emp Designation:");
			String edes=sc.next();
			System.out.println("Enter Emp Insurance scheme:");
			String eins=sc.next();
			
			Employee e1=new Employee(eid,enm,esl,edes,eins);			
			try {
				
				oos.writeObject(e1);
				System.out.println("Emp e1 & e2 is written in the file.");
			}
			catch (IOException e) {
				
				e.printStackTrace();
			}
			}
////////////////////////////////////////////////////////////////DESERIALIZATION/////////////////////////////
			
			FileInputStream fis=null;
			ObjectInputStream ois=null;
			 try {
				 
				fis =new FileInputStream("EmpObj1.obj");
				ois=new ObjectInputStream(fis);
				for(int i=0;i<num;i++) {
				Employee ee = (Employee)ois.readObject();
				System.out.println("Emp Info from file:"+ee);
			} }
			 
			 catch (ClassNotFoundException | IOException e) {//multiCatch feature started from java 7
				
				e.printStackTrace();
			}
			
			
		}

	}





package pack1;

class ApplicationException extends Exception {
    //private int detail;
    ApplicationException() {
      //  detail = a;
     }
	 ApplicationException(String args) {
		super(args);
	 }
     public String toString()      {
        return "ApplicationException";
     }
}

public class PersonMain {

	public PersonMain() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws ApplicationException {
		// TODO Auto-generated method stub
		String fn="Pranav";
		String ln="Agrawal";
		char g='m';
		String fn1="";
		String ln1="";
		char g1='m';
		Person P1 = new Person();
		Person P2 = new Person();
			try {
				P1.setFirstName(fn);
				P1.setLastName(ln);
				P1.setGender(g);
				
				check(fn1,ln1);
				
			}
			catch(ApplicationException e) {
				System.out.println("Exception occured "+e);
			}
			finally {
			System.out.println("First Name:"+P1.getFirstName());
			System.out.println("Last Name:"+P1.getLastName());
			System.out.println("Gender:"+P1.getGender());
			System.out.println();
			System.out.println("First Name:"+P2.getFirstName());
			System.out.println("Last Name:"+P2.getLastName());
			System.out.println("Gender:"+P2.getGender());
			System.out.println("Normal Exit");
			
			}
	}
    static void check(String a,String b) throws ApplicationException {
		if(a.equals("")||b.equals("")) {
			throw new ApplicationException();
		}
	}
	

}

package pack1;

public class Person1 {
	String Name;
	public Person1(String name, float age) {
		super();
		Name = name;
		Age = age;
	}
	float Age;
	
	public Person1() {
		// TODO Auto-generated constructor stub
	}
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public float getAge() {
		return Age;
	}
	public void setAge(float age) {
		Age = age;
	}
	

}

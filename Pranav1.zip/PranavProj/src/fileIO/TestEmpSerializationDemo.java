package fileIO;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

public class TestEmpSerializationDemo  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Emp ID:");
		int eid=sc.nextInt();
		System.out.println("Enter Emp Name:");
		String enm=sc.next();
		System.out.println("Enter Emp Salary:");
		float esl=sc.nextFloat();
		
		Employee e1=new Employee(eid,enm,esl);
		FileOutputStream fos=null;
		
		ObjectOutputStream oos=null;
		
		try {
			fos=new FileOutputStream("EmpObj.obj");
			oos=new ObjectOutputStream(fos);
			oos.writeObject(e1);              //exception because our object is not serializable. so implement serializable in Employee class as comparable in Employee class.
			System.out.println("Emp e1 is written in the file.");
		}
		catch (IOException e) {
			
			e.printStackTrace();
		}
	}

}

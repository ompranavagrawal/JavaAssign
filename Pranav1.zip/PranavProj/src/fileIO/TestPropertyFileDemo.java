package fileIO;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class TestPropertyFileDemo {

	public static void main(String[] args) {
		FileInputStream fis=null;
		Properties myPros=null;
		try {
			fis=new FileInputStream("D://Pranav//PranavProj//src//fileIO//UserInfo.properties");
			myPros=new Properties();
			myPros.load(fis);
			String unm=myPros.getProperty("Userid");
			String pwd=myPros.getProperty("password");
			System.out.println("credentials : " +unm+" : "+pwd);
			System.out.println("*****************************");
			
			Set kS=myPros.keySet();
			Iterator it=kS.iterator();
			while(it.hasNext()) {
				System.out.print(" : "+it.next());
			}
		} 
		
		catch (IOException e) {
			
			e.printStackTrace();
		}

	}

}

package junitPack;

public class HelloWorld {
	
	public String say() {
		return ("Hello World!");
	}
}

package arraysPack3;

public class A1ClassWork {

	public A1ClassWork() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package arraysPack3;

import java.util.Scanner;

public class TestArrayDemo {

	public TestArrayDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String names[]= {"patni","IGate","Copy"};
		System.out.println("*************2d***************");
		int A[][]=new int[3][2];
		A[0][0]=90;
		A[0][1]=90;
		A[1][0]=90;
		A[1][1]=90;
		A[2][0]=90;
		A[2][1]=90;
		
		
		
		System.out.println("***********************************");
		Scanner sc=new Scanner(System.in);
		System.out.println("how many emp do u want?");
		int empCount=sc.nextInt();
		Emp emps[]=new Emp[empCount];
		for(int i=0;i<emps.length;i++) {
			System.out.println("enter emp id:");
			int eId=sc.nextInt();
			System.out.println("enter emp name:");
			String eName=sc.next();
			System.out.println("enter emp salary:");
			float eSal=sc.nextFloat();
			emps[i]=new Emp(eId,eName,eSal);
		}
		
		

	}

}

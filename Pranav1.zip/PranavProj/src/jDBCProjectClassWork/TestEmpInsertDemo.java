package jDBCProjectClassWork;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpInsertDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee ID:");
		int empId=sc.nextInt();
		System.out.println("Enter Employee Name:");
		String empName=sc.next();
		System.out.println("Enter Employee Salary:");
		int empSal=sc.nextInt();
		String insertQry="INSERT INTO Emp_157889 VALUES(?,?,?)";
		
		
		Connection con=null;
		PreparedStatement pst=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","Lab1btrg9","lab1boracle");
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, empId);
			pst.setString(2, empName);
			pst.setInt(3, empSal);
			//int data=pst.executeUpdate();
			int noOfRecAffected=pst.executeUpdate();
			System.out.println(noOfRecAffected+" data is inserted in table.");
		}
		catch (ClassNotFoundException|SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}

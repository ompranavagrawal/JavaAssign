package jDBCProjectClassWork;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class EmpUpdateRecordTestDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee ID whome you want to update:");
		int empId=sc.nextInt();
		System.out.println("Enter the change in Employee Name(if not the write the same as older one):");
		String empName=sc.next();
		System.out.println("Enter the change in Employee Salary(if not the write the same as older one):");
		int empSal=sc.nextInt();
		String insertQry="UPDATE Emp_157889 SET Emp_Name=?,Emp_Sal=? WHERE Emp_ID=?";
		
		
		Connection con=null;
		PreparedStatement pst=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","Lab1btrg9","lab1boracle");
			pst=con.prepareStatement(insertQry);
			pst.setString(1, empName);
			pst.setInt(2, empSal);
			pst.setInt(3, empId);

			int noOfRecAffected=pst.executeUpdate();
			System.out.println(noOfRecAffected+" row is Updated in table.");
		}
		catch (ClassNotFoundException|SQLException e) {
			
			e.printStackTrace();
		}

	}

}

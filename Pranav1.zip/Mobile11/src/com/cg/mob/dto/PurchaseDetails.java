package com.cg.mob.dto;
//CREATE TABLE purchasedetails(purchaseid NUMBER, cname vARCHAR2(20),
//mailid VARCHAR2(30),phoneno VARCHAR2(20), purchasedate DATE, mobileid references mobiles(mobileid));

public class PurchaseDetails extends mobile{
	int purchaseid;
	String cName;
	String mailId;
	String phnoneNo;
	String date;
	int mobileId;
	public PurchaseDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	/*public PurchaseDetails(int mobileid, String mobName, float price, int quantity) {
		super(mobileid, mobName, price, quantity);
		// TODO Auto-generated constructor stub
	}
	public PurchaseDetails(int purchaseid, String cName, String mailId, String phnoneNo, String date, int mobileId) {
		super();
		this.purchaseid = purchaseid;
		this.cName = cName;
		this.mailId = mailId;
		this.phnoneNo = phnoneNo;
		this.date = date;
		this.mobileId = mobileId;
	}*/
	public PurchaseDetails(int mobileid, String mobName, float price, int quantity,int purchaseid, String cName, String mailId, String phnoneNo, String date, int mobileId) {
		super(mobileid, mobName, price, quantity);
		this.purchaseid = purchaseid;
		this.cName = cName;
		this.mailId = mailId;
		this.phnoneNo = phnoneNo;
		this.date = date;
		this.mobileId = mobileId;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseid=" + purchaseid + ", cName=" + cName + ", mailId=" + mailId + ", phnoneNo="
				+ phnoneNo + ", date=" + date + ", mobileId=" + mobileId + ", mobileid=" + mobileid + ", mobName="
				+ mobName + ", price=" + price + ", quantity=" + quantity + "]";
	}
	
	public int getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhnoneNo() {
		return phnoneNo;
	}
	public void setPhnoneNo(String phnoneNo) {
		this.phnoneNo = phnoneNo;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	
	
	
	
}

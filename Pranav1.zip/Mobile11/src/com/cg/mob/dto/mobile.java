package com.cg.mob.dto;
//CREATE TABLE mobiles (mobileid NUMBER PRIMARY KEY,
//name VARCHAR2 (20), price NUMBER(10,2),quantity VARCHAR2(20));
public class mobile {
	int mobileid;
	String mobName;
	float price;
	int quantity;
	
	public mobile() {
		super();
	}
	public mobile(int mobileid, String mobName, float price, int quantity) {
		super();
		this.mobileid = mobileid;
		this.mobName = mobName;
		this.price = price;
		this.quantity = quantity;
	}
	
	@Override
	public String toString() {
		return "mobile [mobileid=" + mobileid + ", mobName=" + mobName + ", price=" + price + ", quantity=" + quantity
				+ "]";
	}
	
	public int getMobileid() {
		return mobileid;
	}
	
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	
	public String getMobName() {
		return mobName;
	}
	
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	
	public float getPrice() {
		return price;
	}
	
	public void setSalary(float price) {
		this.price = price;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}

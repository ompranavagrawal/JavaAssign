package com.cg.mob.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mob.dao.MobDao;
import com.cg.mob.dao.MobDaoImpl;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.dto.mobile;
import com.cg.mob.exception.MobileException;
import com.cg.mob.util.DBUtil;


public class MobDaoImpl implements MobDao {
	
	Logger daoLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	public MobDaoImpl() {
		
		daoLogger=Logger.getLogger(MobDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
	}
	
	@Override
	public ArrayList<PurchaseDetails> getAllMob() throws MobileException
	{
		ArrayList<PurchaseDetails> mobList=null;
		try 
		{
			mobList=new ArrayList<PurchaseDetails>();
			con=DBUtil.getConn();
			System.out.println("*********CON IN DAO ...."+con);
			String selectqry="Select mobiles.mobileid,mobiles.name,mobiles.price,mobiles.quantity,"
					+ "purchasedetails.purchaseid,purchasedetails.cname,purchasedetails.mailid,"
					+ "purchasedetails.phoneno,purchasedetails.purchasedate,purchasedetails.mobileid"
					+ " from mobiles FULL OUTER JOIN purchasedetails ON mobiles.mobileid="
					+ "purchasedetails.mobileid";
			
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next()) {
				mobList.add(new PurchaseDetails(rs.getInt("mobileid"),rs.getString("name"),
						rs.getFloat("price"),rs.getInt("quantity"),
						rs.getInt("purchaseid"), rs.getString("cname"), rs.getString("mailid"),
						rs.getString("phoneno"), rs.getString("purchasedate"), rs.getInt("mobileid")));
				
			}
		} 
		catch (Exception e) 
		{	
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		} 
		finally {
			try {
				st.close();
				rs.close();
				con.close();
			} 
			catch (SQLException e) {
				e.printStackTrace();
				throw new MobileException(e.getMessage());
			}
		}
		daoLogger.info("All data Retrieved"+mobList);
		return mobList;
	}
	
	@Override
	public int addMob(PurchaseDetails mb)  throws MobileException{
		int data=0;
		try {
			//Timestamp date=new Timestamp(new java.util.Date().getTime());
			con=DBUtil.getConn();
			String insertMobileQry="INSERT INTO mobiles VALUES(?,?,?,?)";
			pst=con.prepareStatement(insertMobileQry);
			pst.setInt(1,mb.getMobileid());
			pst.setString(2, mb.getMobName());
			pst.setFloat(3, mb.getPrice());
			pst.setFloat(4, mb.getQuantity());
			data=pst.executeUpdate();  //2 parts me hoga ye
			
			String insertDetailsQry="INSERT INTO purchasedetails VALUES(Sequence.NEXTVAL,?,?,?,?,?)";
			
			pst=con.prepareStatement(insertDetailsQry);//pst.setInt(1,mb.getPurchaseid());
			pst.setString(1, mb.getcName());
			pst.setString(2, mb.getMailId());
			pst.setString(3, mb.getPhnoneNo());
			pst.setString(4, dateSet());
			pst.setFloat(5, mb.getMobileid());
			data=pst.executeUpdate();
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		} 
		
		
		return data;
	}


	public static String dateSet() {
		// TODO Auto-generated method stub
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		String strDate = dateFormat.format(date);
		return strDate;
	}
	PreparedStatement pst1=null;
	PreparedStatement pst2=null;
	
	public void deleteMob(int mid) throws MobileException{
		try {
			con=DBUtil.getConn();
			String deletePurchaseDetailsQry="Delete from purchasedetails where mobileid=?";
			String deleteMobileQry="Delete from mobiles where mobileid=?";
			pst1=con.prepareStatement(deletePurchaseDetailsQry);
			
			
			pst2=con.prepareStatement(deleteMobileQry);
			pst1.setInt(1,mid);
			pst2.setInt(1,mid);
			pst1.executeUpdate(); 
			pst2.executeUpdate(); 
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	PreparedStatement pst3=null;
	public void updatMob(int quant,int mId) throws MobileException {
		try {
			con=DBUtil.getConn();
			String updateQry="update mobiles set quantity = ? where mobileid= ?";
			pst3=con.prepareStatement(updateQry);

			pst3.setInt(1,quant);
			pst3.setInt(2,mId);
			pst3.executeUpdate(); 
			 
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public ArrayList<mobile> searchMob(int min,int max) throws MobileException{
		
		ArrayList<mobile> searchList=null;
		try 
		{
			searchList=new ArrayList<mobile>();
			con=DBUtil.getConn();

			String searchqry="Select mobileid,name,price,quantity from mobiles where price > ? and"
					+ " price < ?";
					
			
			pst=con.prepareStatement(searchqry);
			pst.setInt(1, min);
			pst.setInt(2, max);
			rs=pst.executeQuery(); 
			
			while(rs.next()) {
				searchList.add(new mobile(rs.getInt("mobileid"),rs.getString("name"),
						rs.getFloat("price"),rs.getInt("quantity")));
				
			}
		} 
		catch (Exception e) 
		{	
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		} 
		finally {
			try {
				pst.close();
				rs.close();
				con.close();
			} 
			catch (SQLException e) {
				e.printStackTrace();
				throw new MobileException(e.getMessage());
			}
		}
		daoLogger.info("All data Retrieved"+searchList);
		return searchList;
		
	}	

}

package com.cg.mob.dao;

import java.util.ArrayList;

import com.cg.mob.dto.mobile;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.exception.MobileException;


public interface MobDao {
	
	public ArrayList<PurchaseDetails> getAllMob() throws MobileException;
	
	public int addMob(PurchaseDetails mb)  throws MobileException;
	
	public void deleteMob(int mid) throws MobileException;
	public ArrayList<mobile> searchMob(int min,int max) throws MobileException;

	public void updatMob(int quant, int mId) throws MobileException;
	
}

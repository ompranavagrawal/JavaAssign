package com.cg.mob.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mob.dao.MobDaoImpl;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.dto.mobile;
import com.cg.mob.exception.MobileException;
import com.cg.mob.service.MobServiceImpl;
import com.cg.mob.service.MobService;

public class TestmobMSGClient {
	static MobService mobService=null;
	static Scanner sc;
	
		
		public static void main(String[] args) {
			mobService=new MobServiceImpl();
			sc=new Scanner(System.in);
			System.out.println("*************WELCOME TO EMPLOYEE MANAGEMENT SYSTEM**********");
			int choice=0;
			while(true) {
				System.out.println("What do u want to do?");
				System.out.println("\t1:AddMob\t2:show All Mob\n\t3:Delete Mob\t4:"
						+ "Search Mob\t5:Exit");
				System.out.println("Enter ur choice:");
				choice=sc.nextInt();
				switch (choice) {
				case 1:
					insertMob();
					break;
				
				case 2:
					dispAllMob();
					break;	
					
				/*case 3:
					updateMob();
					
					break;*/
				case 3:
					deleteMob();
					break;
				case 4:
					searchMob();
					break;
						
					
				default:
					System.exit(0);
				}
			}

		}
		private static void searchMob() {
			ArrayList<mobile> searchList=null;
			System.out.println("Enter minimum price range");
			int min=sc.nextInt();
			System.out.println("Enter Maximum price range");
			int max=sc.nextInt();
			////<-----------------------------
			try {
				//mobService.searchMob(min, max);
				searchList=mobService.searchMob(min, max);
				System.out.println("  \tMOBID  \tMOBNAME  \tPRICE  \tQUANTITY");
				for(mobile mb:searchList) {
					System.out.println("\t"+mb.getMobileid()+"\t"+mb.getMobName()+"\t"+mb.getPrice()+
							"\t"+mb.getQuantity());
				}
			} 
			catch (MobileException e) {
				
				e.printStackTrace();
			}
			
		
		}
		/*private static void updateMob(int quant, int mId) {
			
			try {
				mobService.updatMob(quant,mId);
			} catch (MobileException e) {
				
				e.printStackTrace();
			}
		}*/
		private static void deleteMob() {
			System.out.println("Enter Mobile Id to delete");
			int mId=sc.nextInt();
			try {
				mobService.deleteMob(mId);
			} catch (MobileException e) {
				
				e.printStackTrace();
			}
			
		}
		
		private static void dispAllMob() {	
			ArrayList<PurchaseDetails> mobList=null;
			try {
				mobList = mobService.getAllMob();
				
				System.out.println("  \tMOBID  \tMOBNAME  \tPRICE  \tQUANTITY \tPURCHASEID  "
						+ "\tCUSTOMERNAME  \tMAILID  \tPHONENO  \tPURCHASEDATE ");
				System.out.println("-------------------------------------------------------------"
						+ "-------------------------------------------------------------------");
								
				for(PurchaseDetails ee:mobList) {
					System.out.println("\t"+ee.getMobileid()+"\t"+ee.getMobName()+"\t"+ee.getPrice()+
							"\t"+ee.getQuantity()+"\t"+ee.getPurchaseid()+"\t"+ee.getcName()+"\t"+
							ee.getMailId()+"\t"+ee.getPhnoneNo()+"\t"+ee.getDate());
				}
				System.out.println("-------------------------------------------------------------"
						+ "-------------------------------------------------------------------");
			} catch (MobileException e) {
				
				e.printStackTrace();
			}
			
			
		}
		
		private static void insertMob() {
			
			try {
				System.out.println("Enter Mobile Id ");
				int mId=sc.nextInt();
				System.out.println("Enter Mobile name");
				String mnm=sc.next();
				System.out.println("Enter Mobile price");
				float mpr=sc.nextFloat();
				System.out.println("Enter Mobile quantity");
				int mqt=sc.nextInt();
				System.out.println("Enter Customer Name");
				String cnm=sc.next();
				System.out.println("Enter Mail ID");
				String mailId=sc.next();
				System.out.println("Enter Phone number");
				String phno=sc.next();
				
				String purDt=MobDaoImpl.dateSet();
				
				
				if(mobService.validateCustName(mnm)) {
					if(mobService.validateCustName(cnm)) {
						if(mobService.validateMail(mailId)) {
							if(mobService.validateMobNo(phno)) {
								if(mobService.validateMobileId(mId)) {
					
									PurchaseDetails mb=new PurchaseDetails(mId,mnm,mpr,mqt-1,1,cnm,mailId,phno,purDt,mId);
									int dataInserted=mobService.addMob(mb);
									System.out.println("updating..................");
									System.out.println(mId);
									int mqt1=mqt-1;
									System.out.println(mqt1);
									
									//mobService.updatMob(mqt1, mId);
									if(dataInserted==1) {
										
										dispAllMob();
									}
									else {
										System.out.println("Sorry data is not inserted");
									}
								}
							}
						}
					}
				}
				
			}
			catch (MobileException e) {
				
				e.printStackTrace();
			}
		
		}
	

	

	}



package com.cg.mob.service;


import java.util.ArrayList;

import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.dto.mobile;
import com.cg.mob.exception.MobileException;

public interface MobService {
	public ArrayList<PurchaseDetails> getAllMob() throws MobileException;
	
	public int addMob(PurchaseDetails ee)  throws MobileException;
	
	public void deleteMob(int mId) throws MobileException;
	public ArrayList<mobile> searchMob(int min,int max) throws MobileException;
	public boolean validateCustName(String CName) throws MobileException;
	public boolean validateMail(String MailId) throws MobileException;
	public boolean validateMobNo(String mobNo) throws MobileException;
	public boolean validateMobileId(int mobId) throws MobileException;

	public void updatMob(int quant, int mId)throws MobileException;
	
	
	
}


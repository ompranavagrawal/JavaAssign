package com.cg.mob.service;


import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mob.dao.MobDaoImpl;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.dto.mobile;
import com.cg.mob.exception.MobileException;

public class MobServiceImpl implements MobService {
	
	MobDaoImpl mobDao=null;
	public MobServiceImpl() {
		mobDao=new MobDaoImpl();
	}
	@Override
	public ArrayList<PurchaseDetails> getAllMob() throws MobileException{
		return mobDao.getAllMob();
	}
	@Override
	public int addMob(PurchaseDetails mb) throws MobileException{
		return mobDao.addMob(mb);
	}
	@Override
	public void deleteMob(int mId) throws MobileException {
		// TODO Auto-generated method stub
		//return mobDao.deleteMob(mb);
		
	}
	@Override
	public void updatMob(int quant, int mId) throws MobileException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public ArrayList<mobile> searchMob(int min, int max) throws MobileException {
		// TODO Auto-generated method stub
		return mobDao.searchMob(min, max);
	}
	@Override
	public boolean validateCustName(String CName) throws MobileException {//valid customer name
		
		String namePattern="[A-Z][a-z]{2,20}";//{20}";
		if(Pattern.matches(namePattern, CName)) {
			return true;
		}
		else {
			throw new MobileException("Invalid Customer Name should start with capitals "
					+ "and only 20 Characters allowed");
		}
		
	}
	@Override
	public boolean validateMail(String mailId) throws MobileException {//
		
		String mailPattern="^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$";   
		if(Pattern.matches(mailPattern, mailId)) {
			return true;
		}
		else {
			throw new MobileException("Invalid Email Id");
		}
		
	}
	@Override
	public boolean validateMobNo(String mobNo) throws MobileException {//
		
		String mobilePattern="^[0-9]{10}$";   
		if(Pattern.matches(mobilePattern, mobNo)) {
			return true;
		}
		else {
			throw new MobileException("Invalid mobile no.");
		}
		
	}
	@Override
	public boolean validateMobileId(int mobId) throws MobileException {
		
		String mobilePattern="^[0-9]{4}$";   
		if(Pattern.matches(mobilePattern, Integer.toString(mobId))) {
			return true;
		}
		else {
			throw new MobileException("Invalid mobile ID");
		}
		
	}
	
}
	
	

package com.cg.mob.junit;
//Write a test case for insert and search mobile service functionalities.


import org.junit.Test;

import com.cg.mob.dao.MobDaoImpl;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.exception.MobileException;


import junit.framework.Assert;

public class InsertTest {
	
	MobDaoImpl ms=new MobDaoImpl();
	@Test
	public void testInsert() throws MobileException
	{
		PurchaseDetails mb=new PurchaseDetails(1029, "Nokia", 10000, 10, 1, "Pranav", "pranav@gmail.com", "1234567890", MobDaoImpl.dateSet(), 1029); 
		Assert.assertEquals(1, ms.addMob(mb));
		
	}
	public void testSearch() throws MobileException
	{
		
		Assert.assertNotNull(ms);
		
	}
	
	
}


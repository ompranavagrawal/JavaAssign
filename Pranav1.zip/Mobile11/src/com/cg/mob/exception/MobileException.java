package com.cg.mob.exception;


	public class MobileException extends Exception{
		//exception
		String msg;
		Error code;
	    public MobileException(String msg) {
	    	super(msg);
		} 
	    public MobileException(String msg,Throwable cause,Error code) {
	    	super(msg,cause);
	    	this.code=code;
	    }
			

	}


package junitPackAssign;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

public class DateTest {
	//static Calculator calc=null;
	static Date dt=null;
	@BeforeClass                         //only beforeClass and afterClass is static
	public static void setUp() {
		dt=new Date(01,01,2018);
		System.out.println("setup is call Before the execution of all test cases");
		
	}
	@AfterClass								//only beforeClass and afterClass is static
	public static void tearDown() {
		System.out.println("tear down is called after executions of all test cases");
	}
	@Before
	public void init() {
		
		System.out.println("init is call once before the execution of each test cases");
	}
	@After
	public void destroy() {
		System.out.println("destroy is called once after executions of all test cases");
	}
	@Test
	public void testDate1() {
		Assert.assertEquals(1, dt.getDay());//expected,on function
	}
	@Test
	public void testDate2() {
		Assert.assertEquals(1, dt.getMonth()); //expected,on function
	}
	
	//if exception
	//@Test(expected=ArithmeticException.class)
	@Test
	public void testDate3() {
		Assert.assertEquals(2018, dt.getYear()); //expected,on function
	}
	@Test
	public void testDate4() {
		Assert.assertEquals("Date is 1/1/2018", dt.toString()); //expected,on function
	}
}


package junitPackAssign;

import org.junit.Test;

import junit.framework.Assert;

public class Person1Test {
	Person1 pr =new Person1("Pranav","Agrawal",'M');
	@Test
	public void personTest1(){
		Assert.assertEquals("Pranav", pr.getFirstName());
	}
	@Test
	public void personTest2(){
		Assert.assertEquals("Agrawal", pr.getLastName());
	}
	@Test
	public void personTest3(){
		Assert.assertEquals('M', pr.getGender());
	}
	@Test
	public void personTest4(){
		Assert.assertEquals("firstName=Pranav\nlastName=Agrawal\ngender=M" , pr.displayDetails());
	}
}

package junitPackAssign;

import org.junit.Test;

import junit.framework.Assert;

public class EmployeeExceptionTest {
	
	EmployeeException ee=new EmployeeException();
	
	@Test(expected=SalaryException.class)
	public void EEtest1() throws SalaryException{
		Assert.assertEquals(true,EmployeeException.checkSalary(2500)); 
	}
	@Test(expected=SalaryException.class)
	public void EEtest2() throws SalaryException{
		Assert.assertEquals(true,EmployeeException.checkSalary(1000)); 
	}
}

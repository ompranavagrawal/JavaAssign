package junitPackAssign;

class SalaryException extends Exception {
    
	SalaryException() {
     
     }
	SalaryException(String args) {
		super(args);
	 }
     public String toString()      {
        return "SalaryException";
     }
}
public class EmployeeException {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee E1=new Employee();
		String Id="1";
		
		String name="Pranav";
		Double salary=(double) 2999;
		String designation="Analyst";
		String insuranceSceme="LIC";
		
		
		try {
		
			E1.setId(Integer.parseInt(Id));
			E1.setName(name);
			checkSalary(salary);
			E1.setSalary(salary);
			E1.setDesignation(designation);
			E1.setInsuranceScheme(insuranceSceme);
			
		}
		catch(SalaryException e)
		{
			System.out.println("Exception occured "+ e);
		}
		finally {
			System.out.println("normal execution");
			System.out.println(E1.getId());
			System.out.println(E1.getName());
			System.out.println(E1.getSalary());
			System.out.println(E1.getDesignation());
			System.out.println(E1.getInsuranceScheme());
		}

	}
	static boolean checkSalary(double a) throws SalaryException {
		if(a<3000) 
			System.out.println("salary less than 3000");
			throw new SalaryException();
		
	}

}
